<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<HTML><HEAD>
<TITLE>ERRO: A URL solicitada n&atilde;o pode ser recuperada</TITLE>
<STYLE type="text/css"><!--BODY{background-color:#ffffff; font-family:verdana,sans-serif}--></STYLE>
</HEAD><BODY>
<H1>ACESSO PROIBIDO</H1>
<HR noshade size="1px">
<P>
Na tentativa de recuperar a URL:
<A HREF="%U">%U</A>
<P>
O seguinte erro foi encontrado:
<UL>
<LI>
<STRONG>
Proibido o Acesso.
</STRONG>
<P>
O controle de acessos impediu sua requisi&ccedil;&atilde;o.
Em caso de d�vidas, contacte o Helpdesk: 3412-5995/5996. 
Diretoria de Inform�tica - Poder Judici�rio de Pernambuco.
</UL>
</P>

