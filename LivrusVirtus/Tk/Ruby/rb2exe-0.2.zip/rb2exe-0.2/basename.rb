p [$0, File::basename($0, ".*")]
