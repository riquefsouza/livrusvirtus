
#! ruby

def usage
  print <<-EOM.gsub /^\s+/, ''
    rb2exe 0.2 (2000-09-29)
    Usage: rb2exe [options] files...
  EOM
end

usage if ARGV.empty?

ARGV.delete_if do |x| /rb2exe.rb/i === x end

open($0, "rb") do |me|
  stub = me.read.split(/\n#! ruby/)[0]
  for src in ARGV
    dst = File.basename(src, ".*") + ".exe"
    open(dst, "wb") do |exe|
      open(src) do |fh|
        $stderr.print src, " -> ", dst, "\n"
	exe.write stub + "\n"
	script = fh.read
	if not /^#!/ === script
	  exe.write "#! ruby\n"
	end
	exe.write script
      end
    end
  end
end
