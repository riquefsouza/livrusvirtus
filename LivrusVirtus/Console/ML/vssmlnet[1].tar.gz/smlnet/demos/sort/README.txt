Integer Quicksort
=================

This is a simple console application that sorts a given number of
pseudo-random integers.

Build Instructions
------------------

To build the demo , run

build.bat

Running the Code
----------------

To execute the demo, run

Sort.exe [n]

where n is an optional number of pseudo-random integers to sort.  
If omitted, n defaults to 50.












