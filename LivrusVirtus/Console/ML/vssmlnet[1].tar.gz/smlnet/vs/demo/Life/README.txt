Conways Game of Life
====================

Credits
-------

Server.sml is based on code from Chris Reade's book: "Elements of
Functions Programming", Addison-Wesley Publishing, 1989. 

Reproduced with kind permission of the author.

Description
------------

This is a multi-language solution written in a combination of C# and
SML.NET.

The SML.NET sub-project, Server, is a library for computing the
generations in Conways Game of Life using list processing.

The C# sub-project, Client, is a graphical front end that uses the
SML.NET library to present an animated display of the Game of Life.

Despite their names, the Server and Client run in a single process and
just reflect that Server.dll is a library, while Client.exe is the
main executable.


Build Instructions
------------------

To build the demo , choose Build->Solution


Running the Code
----------------

First, Choose Project -> SetStartupProject and make sure Client (not Server)
is the selected startup project.

Then select Debug->Start.

This should build and run the project, popping up a little graphical application.


Debugging
---------

Note that you can set break points in the SML code Server.sml, but the quality
of the experience is currently rather poor because SML.NET does not produce
sufficient debug information.

    

