using System; 
namespace Classes {

public enum MyEnum { A , B , C = A };

}








